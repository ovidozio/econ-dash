import type { Series } from "@/lib/types";

const BLS_BASE = "https://api.bls.gov/publicAPI/v2/timeseries/data/";

export async function fetchBlsSeries(params: {
  seriesId: string;
  startYear?: string;
  endYear?: string;
}): Promise<Series> {
  const { seriesId, startYear = "1960", endYear = new Date().getFullYear().toString() } = params;
  const body: Record<string, any> = {
    seriesid: [seriesId],
    startyear: startYear,
    endyear: endYear,
  };
  const key = process.env.BLS_API_KEY;
  if (key) body.registrationkey = key;

  const res = await fetch(BLS_BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    next: { revalidate: 3600 },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error(`BLS error ${res.status}`);

  const json = await res.json();
  if (json?.status !== "REQUEST_SUCCEEDED") {
    const msg = json?.message?.[0] ?? "Unknown BLS error";
    throw new Error(`BLS: ${msg}`);
  }

  const s = json.Results?.series?.[0];
  if (!s) throw new Error("BLS: no series returned");

  // BLS returns newest-first; also includes M13 = annual average (skip it)
  const points = (s.data as any[])
    .filter((d) => /^M(0[1-9]|1[0-2])$/.test(d.period))
    .map((d) => ({
      time: `${d.year}-${d.period.substring(1)}`, // "YYYY-MM"
      value: d.value == null ? null : Number(d.value),
    }))
    .sort((a, b) => a.time.localeCompare(b.time));

  return {
    id: `bls:${seriesId}`,
    title: seriesId, // catalog can override display name
    unit: undefined, // use product.viz.unitLabel when needed
    frequency: "M",
    points,
    source: {
      name: "Bureau of Labor Statistics",
      url: `${BLS_BASE}${encodeURIComponent(seriesId)}`,
      license: "BLS API Terms",
    },
    meta: { seriesId },
  };
}

