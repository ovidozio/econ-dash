import type { CountryOption, Series, SeriesPoint } from "@/lib/types";

/** Fetch the list of countries from World Bank, filtering out aggregates. */
export async function fetchWorldBankCountries(): Promise<CountryOption[]> {
  const url = "https://api.worldbank.org/v2/country?format=json&per_page=400";
  const resp = await fetch(url, { headers: { Accept: "application/json" }, cache: "no-store" });
  const text = await resp.text();

  if (!resp.ok) {
    throw new Error(`World Bank countries failed (${resp.status}): ${text.slice(0, 300)}`);
  }

  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`World Bank countries not JSON. First 200 chars: ${text.slice(0, 200)}`);
  }

  const rows: any[] = Array.isArray(json) ? json[1] ?? [] : [];
  // Filter out "Aggregates" (region.id === "NA")
  const countries: CountryOption[] = rows
    .filter((r) => r?.region?.id && r.region.id !== "NA")
    .map((r) => ({
      code: String(r?.id || "").toUpperCase(),
      label: String(r?.name || "").trim(),
    }))
    .filter((c) => c.code && c.label)
    .sort((a, b) => a.label.localeCompare(b.label));

  return countries;
}

/** Fetch ONE indicator time series for ONE country. */
export async function fetchWorldBankSeries(dataset: string, country: string): Promise<Series> {
  const url = `https://api.worldbank.org/v2/country/${encodeURIComponent(country)}/indicator/${encodeURIComponent(
    dataset
  )}?format=json&per_page=20000`;

  const resp = await fetch(url, { headers: { Accept: "application/json" }, cache: "no-store" });
  const text = await resp.text();

  if (!resp.ok) {
    throw new Error(`World Bank series failed (${resp.status}): ${text.slice(0, 300)}`);
  }

  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`World Bank series not JSON. First 200 chars: ${text.slice(0, 200)}`);
  }

  const rows: any[] = Array.isArray(json) ? json[1] ?? [] : [];
  const points: SeriesPoint[] = [];

  for (const r of rows) {
    const year = Number(r?.date);
    if (!Number.isFinite(year)) continue;
    const raw = r?.value;
    const value = raw === null || raw === undefined ? null : Number(raw);
    points.push({ year, value });
  }

  // WB returns newest-first → sort ascending
  points.sort((a, b) => a.year - b.year);

  const series: Series = {
    unit: undefined, // Most products supply a unitLabel in the product config.
    series: [
      {
        key: dataset, // chart legend; your product usually overrides metricName
        points,
      },
    ],
    source: { name: "World Bank", url },
    frequency: "A",
  };

  return series;
}

/**
 * OPTIONAL helper: fetch multiple indicators in parallel for one country.
 * Returns a map { indicatorId: SeriesPoint[] }.
 * Safer than the single "multi-id" WB endpoint.
 */
export async function fetchWorldBankIndicators(
  indicators: string[],
  country: string
): Promise<Record<string, SeriesPoint[]>> {
  const out: Record<string, SeriesPoint[]> = {};
  await Promise.all(
    (indicators || []).map(async (id) => {
      const s = await fetchWorldBankSeries(id, country);
      out[id] = s.series[0]?.points ?? [];
    })
  );
  return out;
}

