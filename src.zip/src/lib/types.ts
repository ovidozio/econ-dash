// ---- Common small types -----------------------------------------------------

export type CountryOption = {
  code: string;         // e.g. "USA", "FRA"
  label: string;        // e.g. "United States"
};

export type SeriesPoint = {
  year: number;                     // primary x
  value: number | null;             // y
  // lenient aliases some charts may read:
  t?: number;                       // = year
  v?: number | null;                // = value
  date?: string;                    // ISO date for tooltips if needed
};

export type LineSeries = {
  key: string;                      // legend label
  points: SeriesPoint[];
};

export type Series = {
  unit?: string;                    // "USD", "% of GDP", etc.
  series: LineSeries[];             // one or more lines
  source?: { name: string; url?: string };
  frequency?: "A" | "Q" | "M" | string;
};

// ---- Viz / controls ---------------------------------------------------------

export type ScaleMode = "raw" | "thousand" | "million" | "billion" | "trillion" | "sci";

export type VizControls = {
  scale?: boolean;   // show "raw / thousand / million / ..." toggle
  digits?: boolean;  // show "round digits" toggle
};

export type VizMeta = {
  metricName?: string;
  unitLabel?: string;
  yPrefix?: string;
  ySuffix?: string;
  color?: string;
  showArea?: boolean;
  controls?: VizControls;
  defaultScale?: ScaleMode;
  defaultDigits?: number;
};

// ---- Product metadata -------------------------------------------------------

export type ProviderName =
  | "World Bank"
  | "BLS"
  | "FRED"
  | "Industries"
  | (string & {});

// Country picker modes
export type CountriesConfig =
  | { mode: "worldbank"; default?: string }                      // dynamic WB list
  | { mode: "static"; list: CountryOption[]; default?: string }  // fixed set you supply
  | { mode: "none" };                                            // no picker at all

export type VariantMeta = {
  key: string;           // stable id, used in ?variant=
  label: string;         // human label
  dataset: string;       // dataset id to request when this variant is picked
  unitLabel?: string;
  yPrefix?: string;
  ySuffix?: string;
};

export type ProductMeta = {
  slug: string;
  name: string;
  provider: ProviderName;
  dataset: string;
  tags?: string[];
  image?: string;
  imageFit?: "cover" | "contain";
  logoScale?: number;
  summary?: string;
  description?: string;

  // Countries (expressive form)
  countries: CountriesConfig;

  // Variants (optional)
  variants?: VariantMeta[];
  defaultVariantKey?: string;

  // Visualization defaults
  viz?: VizMeta;
};

