"use client";
import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { getScale, fmtNumber, fmtScientific, type ScaleMode } from "@/lib/format";

type Pt = { time: string; value: number | null };
type LineSeries = { key: string; points: Pt[] };

function colorForIndex(i: number): string {
  // 8 pleasant CSS var fallbacks; if your theme defines these, they’ll apply.
  const vars = [
    "var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)",
    "var(--chart-5)", "var(--chart-6)", "var(--chart-7)", "var(--chart-8)",
  ];
  return vars[i % vars.length];
}

export default function MultiSeriesChart(props: {
  series: { unit?: string; series: LineSeries[] };
  metricName?: string;
  unitLabel?: string;
  controls?: { scale?: boolean; digits?: boolean };
  defaultScale?: ScaleMode;
  defaultDigits?: number;
  height?: number;
}) {
  const { series, unitLabel, controls, defaultScale = "sci", defaultDigits = 2, height = 320 } = props;

  const [scale, setScale] = useState<ScaleMode>(defaultScale);
  const [digits, setDigits] = useState<number>(defaultDigits);

  const lines = series.series ?? [];
  const allPoints = lines.flatMap(s => s.points).filter(p => p.value !== null) as {time:string,value:number}[];
  const year = (t: string) => parseInt(String(t).slice(0,4), 10);
  const maxVal = allPoints.length ? Math.max(...allPoints.map(p => Math.abs(Number(p.value)))) : 0;
  const sc = getScale(scale, maxVal);

  const xDomain = useMemo(() => {
    const ys = allPoints.map(p => year(p.time)).filter(n => Number.isFinite(n));
    if (!ys.length) return undefined;
    return [Math.min(...ys), Math.max(...ys)] as [number, number];
  }, [lines]);

  // Wide table: { x: 1960, "Agriculture": 12.3, "Industry": 28.1, ... }
  const dataWide = useMemo(() => {
    const byYear = new Map<number, any>();
    for (const s of lines) {
      const key = s.key;
      for (const p of s.points) {
        if (p.value == null) continue;
        const y = year(p.time);
        if (!Number.isFinite(y)) continue;
        const row = byYear.get(y) || { x: y };
        row[key] = (scale === "sci") ? Number(p.value) : Number(p.value) / sc.div;
        byYear.set(y, row);
      }
    }
    return Array.from(byYear.values()).sort((a,b)=>a.x-b.x);
  }, [lines, scale, sc]);

  const vf = (v: number) => scale === "sci" ? fmtScientific(v, digits) : fmtNumber(v, digits) + sc.suffix;
  const yLabel = unitLabel || series.unit || "";
  const keys = lines.map(s=>s.key);

  return (
    <div className="w-full">
      <div className="flex items-center justify-end gap-3 mb-2 text-sm">
        {controls?.scale !== false && (
          <select className="border rounded px-2 py-1" value={scale} onChange={e => setScale(e.target.value as ScaleMode)}>
            <option value="sci">Scientific</option>
            <option value="raw">Raw</option>
            <option value="thousand">Thousand</option>
            <option value="million">Million</option>
            <option value="billion">Billion</option>
            <option value="trillion">Trillion</option>
          </select>
        )}
        {controls?.digits !== false && (
          <select className="border rounded px-2 py-1" value={digits} onChange={e => setDigits(Number(e.target.value))}>
            <option value={0}>0 digits</option>
            <option value={1}>1 digit</option>
            <option value={2}>2 digits</option>
            <option value={3}>3 digits</option>
          </select>
        )}
      </div>

      <div style={{ width: "100%", height }}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={dataWide} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis
              dataKey="x"
              type="number"
              domain={xDomain ?? ["dataMin", "dataMax"]}
              tickFormatter={(x)=>String(x)}
              tick={{ fontSize: 12 }}
              tickMargin={8}
              allowDataOverflow
            />
            <YAxis
              yAxisId="left"
              tickFormatter={(v)=>vf(Number(v))}
              tick={{ fontSize: 12 }}
              width={72}
              label={{ value: yLabel, position: "insideLeft", angle: -90, offset: 10, style: { fontSize: 11, opacity: 0.85 } }}
              allowDataOverflow
            />
            <Tooltip formatter={(v:any, name:any)=>[vf(Number(v)), name] } labelFormatter={(l:any)=>String(l)} />
            {keys.map((k, i) => (
              <Line key={k} yAxisId="left" type="monotone" dataKey={k} stroke={colorForIndex(i)} dot={false} strokeWidth={1.8} isAnimationActive={false} />
            ))}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="text-[11px] text-muted-foreground">Tip: drag to zoom (release to apply), double-click to reset.</div>
    </div>
  );
}

